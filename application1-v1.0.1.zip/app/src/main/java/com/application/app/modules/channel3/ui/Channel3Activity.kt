package com.application.app.modules.channel3.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.application.app.R
import com.application.app.appcomponents.base.BaseActivity
import com.application.app.databinding.ActivityChannel3Binding
import com.application.app.modules.channel3.`data`.viewmodel.Channel3VM
import kotlin.String
import kotlin.Unit

public class Channel3Activity : BaseActivity<ActivityChannel3Binding>(R.layout.activity_channel_3) {
  private val viewModel: Channel3VM by viewModels<Channel3VM>()

  public override fun setUpClicks(): Unit {
  }

  public override fun onInitialized(): Unit {
    binding.channel3VM = viewModel
  }

  public companion object {
    public const val TAG: String = "CHANNEL3ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, Channel3Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
