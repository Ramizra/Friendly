package com.application.app.modules.channel3.`data`.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.channel3.`data`.model.Channel3Model

public class Channel3VM : ViewModel() {
  public val channel3Model: MutableLiveData<Channel3Model> = MutableLiveData(Channel3Model())
}
