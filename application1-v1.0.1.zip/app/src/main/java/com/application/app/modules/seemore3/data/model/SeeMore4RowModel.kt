package com.application.app.modules.seemore3.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class SeeMore4RowModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtRadioflash: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_radioflash)

)
