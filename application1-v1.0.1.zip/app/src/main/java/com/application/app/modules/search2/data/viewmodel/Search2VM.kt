package com.application.app.modules.search2.`data`.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.application.app.modules.search2.`data`.model.Search2Model
import com.application.app.modules.search2.`data`.model.Search9RowModel
import kotlin.collections.MutableList

public class Search2VM : ViewModel() {
  public val search2Model: MutableLiveData<Search2Model> = MutableLiveData(Search2Model())

  public val recyclerViewList: MutableLiveData<MutableList<Search9RowModel>> =
      MutableLiveData(mutableListOf())
}
