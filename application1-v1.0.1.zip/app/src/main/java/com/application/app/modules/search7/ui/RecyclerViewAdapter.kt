package com.application.app.modules.search7.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.application.app.R
import com.application.app.databinding.RowSearch8Binding
import com.application.app.modules.search7.`data`.model.Search8RowModel
import kotlin.Int
import kotlin.Unit
import kotlin.collections.List

public class RecyclerViewAdapter(
  public var list: List<Search8RowModel>
) : RecyclerView.Adapter<RecyclerViewAdapter.RowSearch8VH>() {
  private var clickListener: OnItemClickListener? = null

  public fun updateData(newData: List<Search8RowModel>): Unit {
    list = newData
    notifyDataSetChanged()
  }

  public fun setOnItemClickListener(clickListener: OnItemClickListener): Unit {
    this.clickListener = clickListener
  }

  public override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowSearch8VH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_search_8,parent,false)
    return RowSearch8VH(view)
  }

  public override fun onBindViewHolder(holder: RowSearch8VH, position: Int): Unit {
    val search8RowModel = Search8RowModel()
    // TODO uncomment following line after integration with data source
    // val search8RowModel = list[position]
    holder.binding.search8RowModel = search8RowModel
  }

  public override fun getItemCount(): Int = 9
  // TODO uncomment following line after integration with data source
  // list.size

  public interface OnItemClickListener {
    public fun onItemClick(
      view: View,
      position: Int,
      item: Search8RowModel
    ): Unit {
    }
  }

  public inner class RowSearch8VH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    public val binding: RowSearch8Binding = RowSearch8Binding.bind(itemView)
  }
}
