package com.application.app.modules.explore8.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class Explore9RowModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtThriller: String? = MyApp.getInstance().resources.getString(R.string.lbl_thriller)

)
